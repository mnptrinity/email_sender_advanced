<?php
require 'master/PHPMailerAutoload.php'; 
extract($_POST);
if(isset($_POST['name']))
        {
            $name=$_POST['name'];
            $mail=$_POST['email'];
            $message=$_POST['message'];
            $mailto = "tech@servitor.in";
            $mailSub = "FeedBack From The Customer : ".$mail;
            $mailMsg = $message;
            $mail = new PHPMailer();
            $mail ->IsSmtp();
            $mail ->SMTPDebug = 0;
            $mail ->SMTPAuth = true;
            $mail ->SMTPSecure = 'ssl';
            $mail ->Host = "a2plcpnl0572.prod.iad2.secureserver.net";
            $mail ->Port =  465;
            $mail ->IsHTML(true);
            $mail ->Username = "mohan@inspier.in";
            $mail ->Password = "Mohan@007";
            $mail ->SetFrom("mohan@inspier.in");
            $mail->addCC('admin@servitor.in');
            $mail ->Subject = $mailSub;
            $mail ->Body = $mailMsg;
            $mail ->AddAddress($mailto);
            

            if($mail->Send())
             {
                 echo "<script>";
                 echo "window.location.href='http://servitor.in';</script>";
             }
            else
             {
                  echo "<script>";
                 echo "window.location.href='http://servitor.in';</script>";              
             }
                    
         }

      else
      {
           echo "<script>";
                 echo "window.location.href='http://servitor.in';</script>";    
      }
   
    

?>


   

