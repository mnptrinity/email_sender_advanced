<?php
#lets first init the config
###########################
####### init Config #######
###########################
            $name=$_POST['name'];
            $email=$_POST['email'];
            $message=$_POST['message'];
#api key and domain (from mailgun.com panel)
$secretkey='6bbbe45b19ce4afacb6a5cae512ad76b-2ae2c6f3-ffb7d119';
//source domain (you can add your own domain at mailgun panel and use it)
$domain = "sandbox7d8e072ac135473cbf3f734154a2cafc.mailgun.org";

# email options 
$Option['FROM_MAIL']=$email;
$Option['FROM_NAME']="Feedback - ";//any name you want it to appear
$Option['TO_MAIL']="support@servitor.in";
$Option['TO_NAME']='Feedback - support';
$Option['SUBJECT']='Queries or suggestions from the client';
$Option['BODY_TEXT']=$message;// if html is not supported then use text message instead
// $Option['BODY_HTML']="<b style='color:red'>here is html message</b>";


###########################
### Calling mailGun API ###
###########################

# Include the Autoloader
require 'vendor/autoload.php';

# Instantiate the client with option to disable ssl verfication.
$client = new \GuzzleHttp\Client([
    'verify' => false,
]);

# pass the client to Guzzle Adapter
$adapter = new \Http\Adapter\Guzzle6\Client($client);

# pass the Adapter to mailgun object
$mailgun = new \Mailgun\Mailgun($secretkey, $adapter);



# Make the call to the client.
$result = $mailgun->sendMessage($domain, array(
    'from'    => $Option['FROM_NAME'].$name." < ".$Option['FROM_MAIL']." >",
    'to'      => $Option['TO_NAME']." < ".$Option['TO_MAIL']."  >",
    'cc'      => 'tech@servitor.in',
    'subject' => $Option['SUBJECT'],
    'text'    => $Option['BODY_TEXT'],
    // 'html'    => $Option['BODY_HTML'],
));
if($result)
{
    echo "<script>";
                 echo "window.location.href='http://servitor.in';</script>";
}
else
{
    echo "<script>";
                 echo "window.location.href='http://servitor.in';</script>";
}
# result will return as object //lets test it
var_dump($result);
