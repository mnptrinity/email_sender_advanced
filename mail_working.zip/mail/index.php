<?php
// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Load Composer's autoloader
require 'vendor/autoload.php';

// Instantiation and passing `true` enables exceptions
$mail = new PHPMailer(true);
extract($_POST);
if(isset($_POST['name'])&&isset($_POST['email'])&&isset($_POST['message']))
{
    $name=$_POST['name'];
            $email=$_POST['email'];
            $message=$_POST['message'];
            
try {
    //Server settings
    $mail->SMTPDebug = 0;                                       // Enable verbose debug output
    $mail->isSMTP();                                            // Set mailer to use SMTP
    $mail->Host       = 'a2plcpnl0572.prod.iad2.secureserver.net';  // Specify main and backup SMTP servers
    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
    $mail->Username   = 'mohan@inspier.in';                     // SMTP username
    $mail->Password   = 'Mohan@007';                               // SMTP password
    $mail->SMTPSecure = 'ssl';                                  // Enable TLS encryption, `ssl` also accepted
    $mail->Port       = 465;                                    // TCP port to connect to

    //Recipients
    $mail->setFrom($email,$name );
    $mail->addAddress('tech@servitor.in','Feedback - Servitor' );     // Add a recipient
    // $mail->addReplyTo('info@example.com', 'Information');
     $mail->addCC('mohansasireka@gmail.com');
    // $mail->addBCC('bcc@example.com');

    
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'Feedback from the Customer';
    $mail->Body    = $message;
    // $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

if($mail->send())
    {
        echo "message sent";
    }
 echo "<script>";
                // echo "alert('Mail not Sent successfully....Please try after sometime:)');";
                 echo "window.location.href='http://servitor.in';</script>"; } 
                 catch (Exception $e) {
 echo "<script>";
                // echo "alert('Mail not Sent successfully....Please try after sometime:)');";
                 echo "window.location.href='http://servitor.in';</script>"; }
}